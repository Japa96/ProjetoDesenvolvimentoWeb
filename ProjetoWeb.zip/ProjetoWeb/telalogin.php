	<body id="background">
		<div class="container">
		<div class="row">
			<div class="col-md-4">
			</div>
			<div class="col-md-4 mt-5 cpf">
				<form name="form_login" action="index.php" method="post">
					<div class="form-group justify-content-center">
						<label for="exampleInputEmail1">Login:</label>
						<input type="text" name="usuario" class="form-control"  placeholder="Login">
					</div>
					<div class="form-group">
						<label for="exampleInputPassword1">Senha:</label>
						<input type="password" name="senha" class="form-control" placeholder="Senha">
					</div>
					<div class="botao mb-3">
						<button name="validaLogin" type="submit" class="btn btn-danger ml-6">Entrar</button>
					</div>	
				</form>
			</div>
			<div class="col-md-4">
			</div>
		</div>
	</div>

	</body>
	